# Carpeta `exceptions`

Esta carpeta contiene las clases de excepciones personalizadas para el sistema de la tienda.exceptions


## Contenido:

- **StockInsuficienteException.java**: Excepción personalizada que se lanza cuando no hay suficiente stock disponible para completar una compra.

El propósito de esta carpeta es manejar las excepciones específicas de la tienda.
