# Carpeta `app`

Esta carpeta contiene la clase principal `Main.java`, que es donde se ejecuta la aplicación.

## Contenido:

- **Main.java**: Contiene el método `main` de la aplicación. Es responsable de interactuar con el usuario, mostrar el menú y realizar las operaciones relacionadas con la tienda.

El propósito de esta carpeta es proporcionar el punto de entrada para ejecutar el programa y gestionar la interacción del usuario con el sistema de tienda.
