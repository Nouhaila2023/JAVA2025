
package Tema3.ClasesStringStringBuffer;

public class Ejercicio14 {

    /*
     * Cifrado César. Crea un algoritmo de encriptación que se le pase una frase y
     * una clave (numérica). Lo
     * que hará será sumar en ASCII esa clave a cada letra de la frase. Prueba a
     * realizar una función para
     * desencriptar
     */

    public static void main(String[] args) {

    }
}