package Tema3.ClasesStringStringBuffer;

public class Ejercicio6 {

    // . Crea un método que determine si una cadena es un palíndromo, o sea, se lee
    // igual en los dos sentidos.

    public static void main(String[] args) {

    }

}
