package Tema3.ClasesStringStringBuffer;

public class Ejercicio3 {

    /**Diseña un programa en Java que solicite al usuario una cadena en la que buscará y otra que será la
     cadena buscada. El programa indicará cuántas veces aparece la segunda cadena en la primera.*/


    public static void main(String[] args) {


        String texto = "En un lugar de la mancha de cuyo nombre de lo que nose de que";

        int pocicion = texto.indexOf("de");
        int contador = 0;
        String palabra = "de";





        System.out.println(contador);

    }

}
