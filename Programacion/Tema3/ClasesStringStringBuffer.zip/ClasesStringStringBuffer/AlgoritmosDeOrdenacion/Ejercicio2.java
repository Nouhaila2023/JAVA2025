package Tema3.ClasesStringStringBuffer.AlgoritmosDeOrdenacion;

public class Ejercicio2 {

    /*
     * Mejora el método de la burbuja explicado anteriormente y utiliza una variable
     * a
     * modo de centinela o flag, de tal manera que ésta se active cuando hay algún
     * intercambio.
     * En el momento que no haya ningún intercambio, el algoritmo debería parar
     * puesto
     * que el vector ya está ordenado.
     */

    public static void main(String[] args) {

    }
}
