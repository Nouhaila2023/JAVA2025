package Tema3.ArraysMatrices.Matrices;

public class Ejercicio17 {

    /**
     *17. Ordenar matrices. Crea una matriz de enteros de dos dimensiones de 50x50 elementos, rellénala con números
     * aleatorios entre 1 y 500. A continuación, realiza dos funciones:
     * a. ordenaFilas(matriz): que ordene la matriz por filas, cada fila de la matriz quedará ordenada de menor a
     * mayor.
     * b. ordenaColumnas(matriz): que ordene la matriz por columnas, cada columna quedará ordenada de
     * menor a mayor, independientemente de las demás.
     */

    public static void main(String[] args) {


    }
}
