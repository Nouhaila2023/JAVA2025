package Tema6.alquilarPelículas.entidades.enum_;

public enum Genero {
    THRILLER, AVENTURAS, ROMANTICA, ACCION,TERROR, INFANTIL,SCIFI, DRAMA, COMEDIA, ORIENTAL;

}
